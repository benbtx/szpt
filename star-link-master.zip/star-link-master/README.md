### 正常状态

![1](https://github.com/aukocharlie/star-link/blob/master/gif/normal.gif?raw=true)

***

### 鼠标事件

![2](https://github.com/aukocharlie/star-link/blob/master/gif/mousemove.gif?raw=true)

