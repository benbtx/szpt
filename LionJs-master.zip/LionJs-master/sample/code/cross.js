﻿//debugger;

var dataitems =
[
 {
     id: "t1",
     text: "t1",
     x: 100,
     y: 50,
     height: 60,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t2",
     text: "t2",
     x: 100,
     y: 120,
     height: 60,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t3",
     text: "t3",
     x: 100,
     y: 190,
     height: 60,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t4",
     text: "t4",
     x: 100,
     y: 260,
     height: 60,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t5",
     text: "t5",
     x: 100,
     y: 340,
     height: 60,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t6",
     text: "t6",
     x: 100,
     y: 410,
     height: 60,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t7",
     text: "t7",
     x: 200,
     y: 100,
     height: 300,
     width: 20,
     in: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
      { state: 1, id: "9" },
      { state: 1, id: "10" },
      { state: 1, id: "11" },
      { state: 1, id: "12" },
      { state: 1, id: "13" },
      { state: 1, id: "14" },
      { state: 1, id: "15" },
      { state: 1, id: "16" },
      { state: 1, id: "17" },
      { state: 1, id: "18" },
      { state: 1, id: "19" },
      { state: 1, id: "20" },
      { state: 1, id: "21" },
      { state: 1, id: "22" },
      { state: 1, id: "23" },
      { state: 1, id: "24" },
      { state: 1, id: "25" },
      { state: 1, id: "26" },
      { state: 1, id: "27" },
      { state: 1, id: "28" },
      { state: 1, id: "29" },
      { state: 1, id: "30" },
      { state: 1, id: "31" },
      { state: 1, id: "32" },
     ],
     out: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
      { state: 1, id: "9" },
      { state: 1, id: "10" },
      { state: 1, id: "11" },
      { state: 1, id: "12" },
      { state: 1, id: "13" },
      { state: 1, id: "14" },
      { state: 1, id: "15" },
      { state: 1, id: "16" },
      { state: 1, id: "17" },
      { state: 1, id: "18" },
      { state: 1, id: "19" },
      { state: 1, id: "20" },
      { state: 1, id: "21" },
      { state: 1, id: "22" },
      { state: 1, id: "23" },
      { state: 1, id: "24" },
      { state: 1, id: "25" },
      { state: 1, id: "26" },
      { state: 1, id: "27" },
      { state: 1, id: "28" },
      { state: 1, id: "29" },
      { state: 1, id: "30" },
      { state: 1, id: "31" },
      { state: 1, id: "32" },
     ]
 },
 {
     id: "t8",
     text: "t8",
     x: 300,
     y: 50,
     height: 100,
     width: 20,
     in: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
      { state: 1, id: "9" },
      { state: 1, id: "10" },
      { state: 1, id: "11" },
      { state: 1, id: "12" },
      { state: 1, id: "13" },
      { state: 1, id: "14" },
      { state: 1, id: "15" },
      { state: 1, id: "16" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     { state: 1, id: "9" },
     { state: 1, id: "10" },
     { state: 1, id: "11" },
     { state: 1, id: "12" },
     { state: 1, id: "13" },
     { state: 1, id: "14" },
     { state: 1, id: "15" },
     { state: 1, id: "16" },
     ]
 },
 {
     id: "t9",
     text: "t9",
     x: 400,
     y: 50,
     height: 100,
     width: 20,
     in: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t10",
     text: "t10",
     x: 400,
     y: 180,
     height: 60,
     width: 20,
     in: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t11",
     text: "t11",
     x: 400,
     y: 260,
     height: 60,
     width: 20,
     in: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t12",
     text: "t12",
     x: 400,
     y: 340,
     height: 60,
     width: 20,
     in: [
      { state: 1, id: "1" },
      { state: 1, id: "2" },
      { state: 1, id: "3" },
      { state: 1, id: "4" },
      { state: 1, id: "5" },
      { state: 1, id: "6" },
      { state: 1, id: "7" },
      { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t13-1",
     text: "t13",
     x: 500,
     y: 100,
     height: 100,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 }
 ,
 {
     id: "t13-2",
     text: "t13",
     x: 500,
     y: 200,
     height: 100,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t13-3",
     text: "t13",
     x: 500,
     y: 300,
     height: 100,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t13-4",
     text: "t13",
     x: 500,
     y: 400,
     height: 100,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 },
 {
     id: "t14",
     text: "14",
     x: 600,
     y: 100,
     height: 100,
     width: 20,
     in: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ],
     out: [
     { state: 1, id: "1" },
     { state: 1, id: "2" },
     { state: 1, id: "3" },
     { state: 1, id: "4" },
     { state: 1, id: "5" },
     { state: 1, id: "6" },
     { state: 1, id: "7" },
     { state: 1, id: "8" },
     ]
 }

];
var datalink =
    [
{ outid: "t1", outport: "2", inid: "t7", inport: "1", state: 0 },
{ outid: "t1", outport: "3", inid: "t7", inport: "2", state: 1 },
{ outid: "t1", outport: "4", inid: "t7", inport: "3", state: 1 },
{ outid: "t1", outport: "5", inid: "t7", inport: "4", state: 2 },
{ outid: "t2", outport: "1", inid: "t7", inport: "5", },
{ outid: "t2", outport: "2", inid: "t7", inport: "6", },
{ outid: "t2", outport: "3", inid: "t7", inport: "7", },
{ outid: "t2", outport: "4", inid: "t7", inport: "8", },
{ outid: "t7", outport: "1", inid: "t8", inport: "1", },
{ outid: "t7", outport: "2", inid: "t8", inport: "2", },
{ outid: "t7", outport: "3", inid: "t8", inport: "3", },
{ outid: "t7", outport: "4", inid: "t8", inport: "4", },
{ outid: "t7", outport: "6", inid: "t10", inport: "1", },
{ outid: "t7", outport: "7", inid: "t10", inport: "2", },
{ outid: "t7", outport: "8", inid: "t11", inport: "1", },
{ outid: "t7", outport: "9", inid: "t11", inport: "2", },
{ outid: "t7", outport: "10", inid: "t12", inport: "1", },
{ outid: "t7", outport: "11", inid: "t12", inport: "2", },
{ outid: "t4", outport: "2", inid: "t7", inport: "10", },
{ outid: "t4", outport: "3", inid: "t7", inport: "11", },
{ outid: "t5", outport: "2", inid: "t7", inport: "12", },
{ outid: "t6", outport: "2", inid: "t7", inport: "20", },
{ outid: "t6", outport: "3", inid: "t7", inport: "21", },
{ outid: "t6", outport: "4", inid: "t7", inport: "22", },
{ outid: "t8", outport: "2", inid: "t9", inport: "2", },
{ outid: "t8", outport: "3", inid: "t9", inport: "3", },
{ outid: "t8", outport: "4", inid: "t9", inport: "4", },
{ outid: "t9", outport: "1", inid: "t13-1", inport: "2", },
{ outid: "t9", outport: "2", inid: "t13-1", inport: "3", },
{ outid: "t9", outport: "3", inid: "t13-1", inport: "4", },
{ outid: "t10", outport: "1", inid: "t13-2", inport: "1", },
{ outid: "t10", outport: "2", inid: "t13-2", inport: "2", },
{ outid: "t11", outport: "1", inid: "t13-3", inport: "1", },
{ outid: "t11", outport: "2", inid: "t13-3", inport: "2", },
{ outid: "t12", outport: "1", inid: "t13-4", inport: "1", },
{ outid: "t12", outport: "2", inid: "t13-4", inport: "2", },
{ outid: "t13-1", outport: "1", inid: "t14", inport: "1", },
{ outid: "t13-2", outport: "1", inid: "t14", inport: "2", },
{ outid: "t13-3", outport: "1", inid: "t14", inport: "3", },
{ outid: "t13-4", outport: "1", inid: "t14", inport: "4", },

    ];




var scene = stage.currentScene;
var inports = {};
var outports = {};


for (var i = 0; i < dataitems.length; i++) {
    buildElement(dataitems[i], datalink);
}

buildRelation(datalink);


function hasRelation(deviceid, portid, isIn, relation) {

    for (var i in relation) {
        if (!isIn && relation[i].outid == deviceid && relation[i].outport == portid) {
            return true;
        }
        else if (isIn && relation[i].inid == deviceid && relation[i].inport == portid) {
            return true;
        }
    }

    return false;
}

var rect;

function buildElement(data, relation) {
    //创建元素
    var group = stage.new(lion.Group);
    group.dataitem = data;
    group.onHover(function (ele) {

    });
    var rect = stage.new(lion.RectElement);
    rect.backgroundColor = "green";
    rect.foreColor = "#ffffff";
    rect.borderSize = 1;
    rect.width = data.width;
    rect.height = data.height;
    rect.allowMultiline = true;

    rect.x = data.x;
    rect.y = data.y;
    rect.align = lion.Align.Center;
    rect.text = data.text;
    scene.addElement(rect, lion.LayerMode.Action);
    group.add(rect);

    data.ui = rect;



    var step = rect.height / (data.in.length + 1);
    for (var i = 0; i < data.in.length; i++) {
        var line = stage.new(lion.LineElement);
        line.arrowSize = 0;
        line.crossid = data.id;
        line.porttype = "in";
        line.borderSize = 1;
        line.portid = data.in[i].id;

        if (data.in[i].state == 1) {
            if (!hasRelation(data.id, data.in[i].id, true, relation)) {
                line.backgroundColor = "#999999";
            }
            else {
                line.backgroundColor = "green";
            }
        }
        else if (data.in[i].state == 0) {
            line.backgroundColor = "red";
        }

        line.setPoint(rect.x - 20 - 5, rect.y + step * (i + 1), rect.x - 5, rect.y + step * (i + 1));
        scene.addElement(line, lion.LayerMode.Action);
        group.add(line);

        inports[data.id + "_" + data.in[i].id] = line;
    }

    step = rect.height / (data.out.length + 1);
    for (var i = 0; i < data.out.length; i++) {
        var line = stage.new(lion.LineElement);
        line.arrowSize = 0;
        line.crossid = data.id;
        line.porttype = "out";
        line.borderSize = 1;
        if (data.out[i].state == 1) {
            if (!hasRelation(data.id, data.out[i].id, false, relation)) {
                line.backgroundColor = "#999999";
            }
            else {
                line.backgroundColor = "green";
            }
        }
        else if (data.out[i].state == 0) {
            line.backgroundColor = "red";
        }

        line.portid = data.out[i].id;
        line.setPoint(rect.x + rect.width - 5, rect.y + step * (i + 1), rect.x + rect.width + 20 - 5, rect.y + step * (i + 1));
        scene.addElement(line, lion.LayerMode.Action);
        group.add(line);

        outports[data.id + "_" + data.out[i].id] = line;
    }
    scene.addElement(group, lion.LayerMode.Action);
}

function buildRelation(relation) {
    //生成关系
    for (var i in relation) {

        var lineid = relation[i].outid + "_" + relation[i].outport;
        var outline = outports[lineid];


        lineid = relation[i].inid + "_" + relation[i].inport;
        var inline = inports[lineid];

        var link = new lion.RAngleLinkElement() 
        link.arrowDirection = lion.ArrowDirection.Right;
        link.arrowSize = 0;
        link.borderSize = 1;
        link.minInflexion = 30;
        link.canDrag = false;

        link.onHover(function (ele) {
            ele.setTooltip('xxxxx');
        });
        link.onLeave(function (ele) {
            ele.setTooltip();
        });
        if (relation[i].state == 0) {
            link.backgroundColor = "black";
        }
        else if (relation[i].state == 1) {
            link.backgroundColor = "green";
        }
        else if (relation[i].state == 2) {
            link.backgroundColor = "red";
        }
        else if (relation[i].state == 3) {
            link.backgroundColor = "orange";
        }

        try {
            if (relation[i].outid == relation[i].inid) {
                link.setStartAndEndDirection(inline.startNode, outline.endNode, lion.Direction.Right, lion.Direction.Left);
            }
            else {
                link.setStartAndEndDirection(outline.endNode, inline.startNode, lion.Direction.Right, lion.Direction.Left);
            }
            scene.addElement(link);
        }
        catch (e) {
            console.log(e);
        }

    }
}



