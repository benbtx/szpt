﻿

        var ele1 = new lion.RectElement();
        ele1.backgroundColor = "blue";
        ele1.x = 100;
        ele1.y = 100;
        stage.currentScene.addElement(ele1);
        //设置编辑模式
        ele1.setEditMode(lion.EditMode.Scale);




